import{
    GET_USERS_FAIL,
    GET_USERS_REQUEST,
    GET_USERS_SUCCESS,
}   from "../constants/Constants";

export const userReducer = ( state = { users:[] },action)=>{
    switch (action.type) {
        case GET_USERS_REQUEST:
            return { loading:true, users:[]};
        case GET_USERS_SUCCESS:
            return{ loading:false,users:action.payload};
        case GET_USERS_FAIL: 
            return{ loading:false,users:action.payload};
        default:
            return state;
    }
};